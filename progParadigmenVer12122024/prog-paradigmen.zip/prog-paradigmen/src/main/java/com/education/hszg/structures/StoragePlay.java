package com.education.hszg.structures;
import com.education.hszg.structures.api.IntegerStorage;
import com.education.hszg.structures.impl.ArrayListIntegerStorage;

public class StoragePlay {
    //das ist kein Testen

    public static void main(String[] args) {
        //play with ArrayListStorage
        IntegerStorage storage = new ArrayListIntegerStorage();
        storage.add(1);
        storage.add(5);
        storage.add(3, 1);
        storage.remove();
        System.out.println("First element is " + storage.get(0));
        //play with ArrayStorage

        //play with StackStorage

        //play with QueueStorage
    }
}
