# Programmierparadigmen, Java

## Nutzen Sie dieses Projekt für Ihre Aufgaben im Java-Teil der Veranstaltung
